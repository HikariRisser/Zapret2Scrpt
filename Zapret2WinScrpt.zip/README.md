# Zapret2 Windows system controller

[Russian version](README.ru.md) · [Security audit](SECURITY.md) · [License](LICENSE)

Windows controller for `bol-van/zapret2` (release v1.0.6): system-wide DPI
desync for all applications, DoH-based DNS bypass, domain auto-learning and
complete removal from the system.

**The script's console UI is in Russian.**

## Quick start

1. Clone the repository.
2. Run `Zapret2Windows.cmd` **as Administrator**.
3. Choose **[1]** to install. The zapret2 release is downloaded from GitHub
   automatically if it is not present next to the script.
4. Choose **[2]** to start the system-wide bypass.

Menu items:

| Item | Action |
|---|---|
| [1] | Install or update runtime |
| [2] | Start system-wide bypass |
| [3] | Stop |
| [4] | Diagnose resources |
| [5] | Enable autostart at logon |
| [6] | Disable autostart |
| [7] | Show learned domains |
| [8] | Open logs directory |
| [9] | Uninstall from system (driver, task, runtime, hosts) |
| [10] | Refresh DNS via DoH (hosts) |

Installation copies the architecture-matched official `winws2`, WinDivert
driver/DLL, Cygwin runtime, Lua libraries, hostlists, and official WinDivert
filter fragments into `runtime\winws2` and the protected directory
`C:\Windows\System32\Zapret2Windows`.

Start enables system-wide WinDivert interception. This is not a browser proxy:
TCP/UDP traffic from all applications is eligible for interception.

Command-line equivalents:

```powershell
powershell -ExecutionPolicy Bypass -File .\Zapret2Windows.ps1 -Action Install
powershell -ExecutionPolicy Bypass -File .\Zapret2Windows.ps1 -Action Start
powershell -ExecutionPolicy Bypass -File .\Zapret2Windows.ps1 -Action Status
powershell -ExecutionPolicy Bypass -File .\Zapret2Windows.ps1 -Action Diagnose
powershell -ExecutionPolicy Bypass -File .\Zapret2Windows.ps1 -Action DohHosts
powershell -ExecutionPolicy Bypass -File .\Zapret2Windows.ps1 -Action Stop
powershell -ExecutionPolicy Bypass -File .\Zapret2Windows.ps1 -Action Uninstall
```

## What is implemented

- official x64/x86 release selection based on Windows architecture;
- WinDivert full-port interception for TCP 80/443 and UDP 443, both directions;
- official `zapret-lib.lua` and `zapret-antidpi.lua` from the same release;
- HTTP strategy: fake + multisplit;
- TLS strategy: fake + multidisorder with ClientHello reassembly enabled;
- QUIC strategy: fake on `quic_initial`;
- **Discord voice/media profile**: fake on `discord_ip_discovery`, `stun`,
  `wireguard_initiation`, `wireguard_cookie` (official zapret2 scheme from
  `init.d/custom.d.examples.*/50-discord-media`, `50-stun4all`, `50-wg4all`);
- official Discord media, STUN, and WireGuard raw filter fragments;
- static hostlist plus zapret2 autohostlist feedback;
- **DNS over DoH** for DNS-level blocks (marked block in `hosts`, removed by
  `Uninstall`);
- **full uninstall** (process, task, kernel service, runtime directory, hosts);
- logs, PID tracking, safe stop, status, diagnostics, and autostart;
- no TLS MITM, no root certificate, no browser-specific configuration.

The runtime starts with a conservative seed list. zapret2's autohostlist
learns domains when its failure detector sees retransmissions/RST/insufficient
responses. The learned list is stored in:

```text
runtime\winws2\lists\autohostlist.txt
```

## Discord voice

Voice uses a different transport than the web client: a UDP media path plus a
WebSocket gateway for signaling. The controller therefore has a dedicated 4th
profile that desyncs `discord_ip_discovery`, `stun`, and WireGuard payloads, and
the WinDivert capture includes the official media/UDP fragments.

Verified on this host:

| check | result |
|---|---|
| HTTPS API (`/api/v9/gateway`) | 200 |
| HTTPS API (`/api/v9/voice/regions`) | 401 (reachable; login required) |
| WSS voice gateway `gateway.discord.gg` | Hello `op=10`, heartbeat present |
| UDP STUN binding (Google / Cloudflare) | `0x0101` success, mapped address returned |
| Profile on `discord_ip_discovery` (debug) | `profile 4 matches` → `fake_4_1 desync` |
| Profile on `stun` (debug) | `fake_4_1 : payload_type 'stun' satisfy filter` |

Debug trace for a synthetic 74-byte IP-discovery packet on port 50000:

```text
UDP: len=74 : 00 01 00 46 ...
packet contains discord_ip_discovery payload
discovered l7 protocol
desync profile 4 (noname) matches
* lua 'fake_4_1' : payload_type 'discord_ip_discovery' satisfy filter
* lua 'fake_4_1' : desync
```

**Limitation:** a full voice session (joining a channel with two-way audio)
cannot be verified without a logged-in Discord client, because the real voice
endpoint is only issued after authentication. All measurable transports were
checked: signaling (WSS), the API, and the UDP media path, plus proof that the
voice profile actually fires.

## Security

Live resources (Lua, lists, filters and the kernel driver) are placed in
`C:\Windows\System32\Zapret2Windows`, where ordinary users have read-only
access. This is deliberate: the project working folder may be writable by other
users, while `winws2` executes Lua inside a process running with
administrator/SYSTEM rights and kernel-driver access. See
[SECURITY.md](SECURITY.md) for the full threat review, what was fixed, and what
remains.

Before enabling autostart, move `Zapret2Windows.ps1` itself into a directory
that ordinary users cannot write to; otherwise the SYSTEM task stays a
privilege-escalation vector.

## Uninstall

Menu item **[9]** (or `-Action Uninstall`) removes the project from the system
in five steps:

| Step | Removed |
|---|---|
| 1/5 | `winws2` process |
| 2/5 | `Zapret2Windows` scheduled task (autostart) |
| 3/5 | `WinDivert` kernel service |
| 4/5 | `C:\Windows\System32\Zapret2Windows` protected directory |
| 5/5 | marked block in `hosts` (ours and the one from the older project) |

It then prints a leftover check for every component. The command is
idempotent. A `hosts.zapret-backup` copy is created before editing `hosts`.

Variants:

```powershell
.\Zapret2Windows.ps1 -Action Purge -IncludeProject   # also remove project runtime
.\Zapret2Windows.ps1 -Action Uninstall -KeepLogs     # keep a copy of logs
.\Zapret2Windows.ps1 -Action Uninstall -Force        # no confirmation prompt
```

**Not touched:** certificate store, other files in `System32`, unrelated `hosts`
entries, the project folder (unless `-IncludeProject`).

## DNS over DoH

DPI desync cannot help when the ISP returns no IP at all (DNS block):
`youtube.com` and `rutracker.org` simply do not resolve. The controller
therefore resolves names over DoH (Cloudflare, Google, Quad9) and writes the
result into `hosts` as a marked block:

```
# --- Zapret2Windows DoH begin ---
172.67.182.196	rutracker.org
...
# --- Zapret2Windows DoH end ---
```

Runs automatically on `Install`; manually via menu **[10]** or
`-Action DohHosts`. Note that `hosts` matches exact names, so `www` variants
are resolved separately. Removed completely by `Uninstall`.

## Important limits

This is a system-wide DPI desync controller, not a VPN. It can handle traffic
that is reachable at the IP/TCP level but interfered with by DPI. It cannot
restore a route when every destination IP is filtered, and it cannot turn a
local SOCKS proxy into a transparent system tunnel. Full IP/routing blocks and
arbitrary UDP services require an external system route such as WireGuard,
Wintun/TUN, or another VPN endpoint.

HTTP/2 is deliberately not rewritten. The release supports TLS ClientHello
reassembly for desync, but stock `tls_mod` has no ALPN modification. Unsafe
Lua packet replacement can invalidate TCP sequence/reassembly and break TLS.

The script therefore does not promise that every site or protocol will work:
its diagnostic output separates TCP reachability, HTTP result, and WinDivert
startup errors. A `200` from one HTTP request is not proof that every native
application, WebSocket, QUIC, or UDP media flow works.

## Project structure

```
zapret2-windows/
├── Zapret2Windows.ps1   — controller (install, start, diagnose, uninstall)
├── Zapret2Windows.cmd   — launcher that requests administrator rights
├── README.md            — documentation (English)
├── README.ru.md         — documentation (Russian)
├── SECURITY.md          — security audit: threats and what was fixed
├── LICENSE              — MIT
├── .gitignore
├── tools/               — optional diagnostics
│   ├── probe-h2.js      — HTTP/2 versus HTTP/1.1
│   └── probe-voice.js   — Discord voice transport
├── runtime/             — created on install (not in git)
└── zapret2-v1.0.6/      — upstream release, downloaded on install (not in git)
```

## Diagnostics (tools/)

Optional Node.js scripts that help locate the failing layer:

```bash
node tools/probe-h2.js discord.com rutracker.org www.youtube.com
node tools/probe-voice.js
```

`probe-h2.js` compares HTTP/2 and HTTP/1.1 — it shows whether HTTP/2
specifically breaks. `probe-voice.js` checks Discord voice signaling (HTTPS
API, WSS gateway) and the UDP media path (STUN).

## Source and release

Upstream repository: <https://github.com/bol-van/zapret2>

The zapret2 build is **not stored in the repository** — it is downloaded from
the official release during installation (or placed manually into
`zapret2-v1.0.6/`). Keep `winws2.exe`, WinDivert files, and Lua libraries from
the same release together; mismatched versions break compatibility
(`NFQWS2_COMPAT_VER`).

## Publishing to GitHub

The repository is ready: `.gitignore`, `LICENSE`, documentation, and a clean
split between code and generated files. The zapret2 build and `runtime/` are
**not** committed — they are downloaded/created during installation.

```bash
git init
git add .
git commit -m "Zapret2 Windows: system-wide DPI desync controller"
git branch -M main
git remote add origin https://github.com/<user>/<repo>.git
git push -u origin main
```

Tracked: `.gitignore`, `LICENSE`, `README.md`, `README.ru.md`, `SECURITY.md`,
`Zapret2Windows.cmd`, `Zapret2Windows.ps1`, `tools/probe-h2.js`,
`tools/probe-voice.js`.
Ignored: `runtime/`, `zapret2-v1.0.6/`, `*.log`, `*.zapret-backup`.

## License

MIT — see [LICENSE](LICENSE). zapret2 is distributed under the MIT License,
Copyright (c) 2016-2026 bol-van.
